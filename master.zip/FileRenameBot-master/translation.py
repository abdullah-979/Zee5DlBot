class Translation(object):
    START_TEXT = """ <b> Helo {} , I'm A Simple File Renamer & File To Video Converter Bot With Permanent Thumbnail support... </b> \n

<b>Bot Maintained By: @Doraemon_Tamil </b> \n
<b>Do /help for more...</b> \n
"""

    RENAME_403_ERR = "What Are You Doing? Bruuh!!"
    BANNED_USER_TEXT = "Sorry!! But Mai Owner As Banned You From Using This Service. That Means You Can't Run Meh Now! \n \n Contact : @Doraemon_Tamil For more Details.. " 
    ABS_TEXT = "What Are You Trying To Do,Mate?"
    UPGRADE_TEXT = "CONTACT @AbdullahTN "
    DOWNLOAD_START = "<b>Downloading To My server !! pls Wait</b>"
    UPLOAD_START = "<b>Downloading Completed Now I'm Uploading Into Telegram</b>"
    RCHD_TG_API_LIMIT = "Downloaded in {} seconds.\nDetected File Size: {}\nSorry WTF Do You Think! I'll Upload It?"
    AFTER_SUCCESSFUL_UPLOAD_MSG = "**Thank you for Using Me SHARE > ❤️**"
    AFTER_SUCCESSFUL_UPLOAD_MSG_WITH_TS = "Downloaded in {} seconds.\nUploaded in {} seconds"
    NOT_AUTH_USER_TEXT = "CONTACT @AbdullahTN "
    NOT_AUTH_USER_TEXT_FILE_SIZE = "IF You Got This Message You Should Contact @AbdullahTN "
    SAVED_CUSTOM_THUMB_NAIL = "<b>thumbnail Saved ✅ This Is Permanent Until</b> /delthumb ❤"
    DEL_ETED_CUSTOM_THUMB_NAIL = "thumbnail cleared succesfully🤦"
    FF_MPEG_DEL_ETED_CUSTOM_MEDIA = "Media cleared succesfully."
    SAVED_RECVD_DOC_FILE = "<b>File Downloaded Successfully 😎</b>"
    REPLY_TO_DOC_FOR_RENAME_FILE = "<b>Please Reply To An File With /rename fil name extension To rename a file</b>"
    REPLY_TO_DOC_FOR_C2V = "<b> Please Reply To An File With /c2v To Convert It Into Streamable video File</b>"
    REPLY_TO_DOC_FOR_C2A = "<b> Please Reply To An File/video With /c2a To Convert It Into Audio File</b>"
    CUSTOM_CAPTION_UL_FILE = " "
    NO_THUMB_FOUND = "No Thumbnail found"
    USER_ADDED_TO_DB = "User <a href='tg://user?id={}'>{}</a> added to {} till {}."
    IFLONG_FILE_NAME = """You Gotta Be Kidding Me...Decrease The Number Of Letters😆😉"""
    ABOUT_ME = """<b>Meh : \n An Telegram File Renamer Bot Which Can Rename A Telegram Files. \n You Can Set Permanent Thumbnail For The File So You Don't Have To Send Custom Thumbs All The Time.\n \n i can also convert files into videos \n Feedback @DoraemonTamil If You Found Meh Useful</b>"""
    HELP_USER = """Ohh You Want Help?? 😅
    
1.🔹 <b>Send me any Telegram File.</b> \n
2.🔹 <b>Reply to that message with /rename New file name.extnsion</b> \n
3.🔹 <b> Send A Photo to make it as permanent Thumbnail</b> \n
4.🔹 <b> I Can Also Convert Files Into Video through /c2v Command </b>   \n \n <b>Made With Love By: @Doraemon_Tamil </b>"""

